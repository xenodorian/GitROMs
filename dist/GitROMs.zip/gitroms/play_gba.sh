#!/bin/bash
# Starts one GBA ROM from the ports menu: play_gba.sh <rom file name in the gba folder> <title>
# The ROM is downloaded and kept current by GitROMs into <roms>/gba. It is played by ArkOS's own GBA emulator: the command that
# EmulationStation itself would run for the gba system is read from es_systems.cfg. If that cannot be used, RetroArch is
# started directly with an mGBA or gpSP core. Everything is logged with times to gitroms/data/play.log.
ROMFILE="$1"; TITLE="${2:-$1}"
PORTSDIR="$(cd "$(dirname "$0")/.." && pwd)"
GAMEDIR="$PORTSDIR/gitroms"
ROM="${GITROMS_GBA_DIR:-$(dirname "$PORTSDIR")/gba}/$ROMFILE"
XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}
for controlfolder in /opt/system/Tools/PortMaster /opt/tools/PortMaster "$XDG_DATA_HOME/PortMaster" /roms/ports/PortMaster; do [ -d "$controlfolder" ] && break; done
[ -f "$controlfolder/control.txt" ] && source "$controlfolder/control.txt" 2>/dev/null

mkdir -p "$GAMEDIR/data"
LOG="$GAMEDIR/data/play.log"
[ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 131072 ] && mv -f "$LOG" "$GAMEDIR/data/play.prev.log"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }
say() {
  echo "$*"
  if type pm_message >/dev/null 2>&1; then pm_message "$*"; else echo "$*" > /dev/tty1 2>/dev/null; fi
}
# What can feed keys to the game right now: input-related processes (a leftover gptokeyb turns the pad into keyboard keys) and input devices with their handlers.
inputsnap() {
  echo "processes: $(ps -eo pid=,etimes=,comm= 2>/dev/null | grep -E 'gptokeyb|retroarch|ogage|oga_controls|emulationstation|joy2key|evtest|sdl' | awk '{printf "%s(pid %s, age %ss) ", $3, $1, $2}')"
  echo "input devices (name [handlers]):"
  awk 'BEGIN { RS = ""; FS = "\n" } { n = ""; h = ""; for (i = 1; i <= NF; i++) { if ($i ~ /^N: Name=/) { n = $i; sub(/^N: Name=/, "", n) } if ($i ~ /^H: Handlers=/) { h = $i; sub(/^H: Handlers=/, "", h) } } print "  " n " [" h "]" }' /proc/bus/input/devices 2>/dev/null | head -12
}
# Controller context for the report: only what is needed to see how ArkOS and RetroArch map the GBA A and B buttons.
sysinfo() {
  echo "=== launcher side (ArkOS / RetroArch) ==="
  echo "date: $(date '+%Y-%m-%d %H:%M:%S')"
  [ -f /etc/os-release ] && grep -E '^PRETTY_NAME=' /etc/os-release 2>/dev/null
  for f in /home/ark/.config/.version /opt/system/version; do [ -f "$f" ] && echo "arkos version file $f: $(head -c 60 "$f" 2>/dev/null)"; done
  echo "started with: ${CMD:-RetroArch ${RA:-unknown} core ${CORE:-unknown}}"
  echo "--- input state when the game started"
  cat "$GAMEDIR/data/input_launch.txt" 2>/dev/null
  echo "--- input state when the game exited"
  inputsnap
  local cfg d f n names found=0 rn=0
  for cfg in "$HOME/.config/retroarch/retroarch.cfg" /home/ark/.config/retroarch/retroarch.cfg /home/ark/.config/retroarch32/retroarch.cfg /opt/retroarch/retroarch.cfg; do
    [ -f "$cfg" ] || continue
    echo "--- $cfg"
    grep -E '^(input_joypad_driver|input_player1_(a|b)_(btn|axis)|input_player1_joypad_index|menu_swap_ok_cancel_buttons)' "$cfg" 2>/dev/null | head -10
    d="$(dirname "$cfg")"
    for f in "$d"/config/remaps/*mGBA*/* "$d"/config/remaps/*gpSP*/* "$d"/config/remaps/*gba*/*; do
      [ -f "$f" ] || continue
      rn=$((rn + 1)); [ "$rn" -le 3 ] || break
      echo "--- remap $f"; grep -E '^input_player1_btn_(a|b) ' "$f" 2>/dev/null | head -4
    done
  done
  # the controller profile RetroArch picked for a connected device: its A and B lines only
  names="$(sed -n 's/^N: Name="\(.*\)"$/\1/p' /proc/bus/input/devices 2>/dev/null)"
  while IFS= read -r n; do
    [ -n "$n" ] || continue
    for f in /home/ark/.config/retroarch/autoconfig/udev/*.cfg /home/ark/.config/retroarch/autoconfig/*.cfg /opt/retroarch/autoconfig/udev/*.cfg /etc/retroarch/autoconfig/udev/*.cfg; do
      [ -f "$f" ] && grep -q -F "input_device = \"$n\"" "$f" 2>/dev/null || continue
      [ "$found" -lt 2 ] || break 2
      found=$((found + 1))
      echo "--- profile $f"; grep -E '^input_(a|b)_(btn|axis) ' "$f" 2>/dev/null | head -4
    done
  done <<< "$names"
}
# Lift a controller report the game stored in the save (flash sector 31) into sgba/reports, with the controller context above.
# The same report stays in the save, so it is only lifted again when its text changed.
extract_report() {
  local sav="" cand
  for cand in "${ROM%.gba}.srm" "${ROM%.gba}.sav"; do
    [ -f "$cand" ] && sav="$cand" && break
  done
  [ -n "$sav" ] || return 0
  local out="$PORTSDIR/sgba/reports" body
  body="$(python3 - "$sav" <<'PY' 2>/dev/null
import sys
data = open(sys.argv[1], "rb").read()
i = data.find(b"PWAMRPT")
if i >= 0:
    sys.stdout.write(data[i:i+3000].split(b"\x00", 1)[0].decode("latin1", "replace"))
PY
)"
  [ -n "$body" ] || return 0
  local sum last="$GAMEDIR/data/last_report.sum"
  sum="$(printf '%s' "$body" | cksum | cut -d' ' -f1,2)"
  [ -f "$last" ] && [ "$(cat "$last" 2>/dev/null)" = "$sum" ] && return 0
  mkdir -p "$out"
  { echo "Pokemon War and Murder controller report"
    echo "How to read it: the game logs the raw GBA key register every frame while the player presses A, then B (0001 = GBA A, 0002 = GBA B). A different bit or nothing means ArkOS / RetroArch maps that button elsewhere; the launcher part below shows the mapping."
    echo "$body"
    sysinfo | head -c 6000; } > "$out/controller-$(date +%s).txt" 2>/dev/null && echo "$sum" > "$last"
  log "controller report written to $out"
}

done_() { type pm_finish >/dev/null 2>&1 && pm_finish; exit "${1:-0}"; }

log "start: $TITLE rom=$ROM"
inputsnap > "$GAMEDIR/data/input_launch.txt" 2>/dev/null
pidof gptokeyb >/dev/null 2>&1 && log "gptokeyb is running before the game starts (pid $(pidof gptokeyb)); left alone"
if [ ! -s "$ROM" ]; then
  log "rom missing or empty"
  say "$TITLE is not on this card yet. Open GitROMs and download it first."
  sleep 6; done_ 1
fi

run_logged() { log "run: $*"; ( eval "$@" ) >> "$LOG" 2>&1; rc=$?; log "exit code $rc"; return $rc; }

# 1. The command EmulationStation uses for the gba system.
CFG=""
for f in "${ES_SYSTEMS_CFG:-}" /etc/emulationstation/es_systems.cfg "$HOME/.emulationstation/es_systems.cfg" /opt/system/es_systems.cfg; do
  [ -n "$f" ] && [ -f "$f" ] && CFG="$f" && break
done
CMD=""
if [ -n "$CFG" ]; then
  CMD="$(sed 's/<system>/\n<system>/g' "$CFG" | awk '/<system>/{blk=""} {blk=blk $0 "\n"} /<\/system>/{ if (blk ~ /<name>gba<\/name>/ && match(blk, /<command>[^<]*<\/command>/)) { s=substr(blk, RSTART+9, RLENGTH-19); print s; exit } }')"
fi
log "es_systems: ${CFG:-none}; command: ${CMD:-none}"
if [ -n "$CMD" ] && ! echo "$CMD" | grep -q '%EMULATOR%\|%CORE%\|%INJECT%\|%SYSTEM%\|%GAMEDIR%'; then
  q="'${ROM//\'/\'\\\'\'}'"
  CMD="${CMD//%ROM_RAW%/$ROM}"; CMD="${CMD//%ROM%/$q}"; CMD="${CMD//%BASENAME%/$(basename "$ROMFILE" .gba)}"
  run_logged "$CMD"; rc=$?; extract_report
  [ "$rc" -eq 0 ] && done_ 0
  log "es command failed, trying RetroArch"
fi

# 2. RetroArch directly.
RA=""
for b in /opt/retroarch/bin/retroarch /usr/local/bin/retroarch /usr/bin/retroarch "$(command -v retroarch 2>/dev/null)"; do
  [ -n "$b" ] && [ -x "$b" ] && RA="$b" && break
done
CORE=""
for d in "$HOME/.config/retroarch/cores" /home/ark/.config/retroarch/cores /opt/retroarch/cores /usr/lib/libretro /usr/lib/aarch64-linux-gnu/libretro "${RA_CORES:-}"; do
  for n in mgba gpsp vba_next; do [ -n "$d" ] && [ -f "$d/${n}_libretro.so" ] && CORE="$d/${n}_libretro.so" && break 2; done
done
log "retroarch: ${RA:-none} core: ${CORE:-none}"
if [ -n "$RA" ] && [ -n "$CORE" ]; then
  run_logged "\"$RA\" -L \"$CORE\" \"$ROM\""; rc=$?; extract_report
  [ "$rc" -eq 0 ] && done_ 0
fi
say "Could not start $TITLE. See gitroms/data/play.log, or start it from the GBA system."
sleep 6; done_ 1
